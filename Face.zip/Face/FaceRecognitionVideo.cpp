/*
 * Recognition of my face from the video camera by training on preproccessed images
 * Reference: http://docs.opencv.org/2.4/modules/contrib/doc/facerec/tutorial/facerec_video_recognition.html
 */

#include "opencv2/contrib/contrib.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/objdetect/objdetect.hpp"

#include <iostream>
#include <fstream>
#include <sstream>

using namespace cv;
using namespace std;

static void read_csv(const string& filename, vector<Mat>& images, vector<int>& labels, char seperator = ';') {
	std::ifstream file(filename.c_str(), ifstream::in);

	if (!file) {
		string error_message = "No valide input file is given, please check the given filename";
		CV_Error(CV_StsBadArg, error_message);
	}

	string line, path, classlabel;
	while (getline(file, line)) {
		stringstream liness(line);
		getline(liness, path, seperator);
		getline(liness, classlabel);

		if (!path.empty() && !classlabel.empty()) {
			images.push_back(imread(path, 0));
			labels.push_back(atoi(classlabel.c_str()));
			cout << path << "\t" << imread(path).total() << endl;
		}
	}
}


int main(){

	string faceHaar = "E:/OpenCV-2.4.13/opencv/sources/data/haarcascades/haarcascade_frontalface_alt.xml";
	int deviceId = 0;

	string fn_csv = "./Dataset/att2.csv";
	vector<Mat> images;
	vector<int> labels;

	//Read the csv file
	try {
		read_csv(fn_csv, images, labels);
	}
	catch (cv::Exception& e) {
		cerr << "Error opening file \"" << fn_csv << "\". Reason: " << e.msg << endl;
		exit(1);
	}

	//Quit if there are not enough images for this demo
	if (images.size() <= 1) {
		string error_message = "This demo needs at least 2 images to work. Please add more images to your data set!";
		CV_Error(CV_StsError, error_message);
	}


	// Read in the data from the csv file
	/*for (int i = 0; i < 21; i++){
		images.push_back(imread(photosPath[i]));
	} */

	// Get height and width from the 1st image to resize
	int imgWidth = images[0].cols;
	int imgHeight = images[0].rows;

	
	// test sample
	//Mat testSample = images[images.size() - 1];

	//int label = 1;
	//images.pop_back();

	// train the model based on the dataset
	cout << "Training the model" << endl;
	Ptr<FaceRecognizer> model = createEigenFaceRecognizer();
	model->train(images, labels);

	
	// That's it for learning the Face Recognition model. You now
	// need to create the classifier for the task of Face Detection.
	CascadeClassifier face_cascade;
	if (!face_cascade.load(faceHaar)) {
		cout << "--(!)Error loading face cascade" << endl;
		return -1;
	}

	VideoCapture cap(deviceId);
	// Check if we can use this device at all:
	if (!cap.isOpened()) {
		cerr << "Capture Device ID " << deviceId << "cannot be opened." << endl;
		return -1;
	}

	//Capture image from Video Camera
	Mat frame;
	for (;;) {
		cap >> frame;
		// Clone the current frame:
		Mat original = frame.clone();
		// Convert the current frame to grayscale:
		Mat gray;
		cvtColor(original, gray, CV_BGR2GRAY);
		// Find the faces in the frame:
		vector< Rect_<int> > faces;
		face_cascade.detectMultiScale(gray, faces);
		
		for (int i = 0; i < faces.size(); i++) {
			// Process face by face:
			Rect face_i = faces[i];
			// Crop the face from the image. So simple with OpenCV C++:
			Mat face = gray(face_i);

			Mat face_resized;
			cv::resize(face, face_resized, Size(imgWidth, imgHeight), 1.0, 1.0, INTER_CUBIC);
			// Now perform the prediction, see how easy that is:
			int prediction = model->predict(face_resized);
			//int prediction = 1;
			// And finally write all we've found out to the original image!
			// First of all draw a green rectangle around the detected face:
			if (prediction == 23)
				rectangle(original, face_i, CV_RGB(255, 255, 0), 1);
			else
				rectangle(original, face_i, CV_RGB(0, 255, 0), 1);
			// Create the text we will annotate the box with:
			string box_text = format("Prediction = %d", prediction);
			// Calculate the position for annotated text (make sure we don't
			// put illegal values in there):
			int pos_x = std::max(face_i.tl().x - 10, 0);
			int pos_y = std::max(face_i.tl().y - 10, 0);
			// And now put it into the image:
			putText(original, box_text, Point(pos_x, pos_y), FONT_HERSHEY_PLAIN, 1.0, CV_RGB(0, 255, 0), 2.0);
			if (prediction == 9 || prediction == 23){
				cv::Rect region(faces[i].x, faces[i].y, faces[i].width, faces[i].height);
				cv::GaussianBlur(original(region), original(region), Size(0, 0), 10);
			}
			
		} 
		// Show the result:
		imshow("face_recognizer", original);
		// And display it:
		char key = (char)waitKey(20);
		// Exit this loop on escape:
		if (key == 32)
			break;
	}
	
	cv::waitKey(0);
	return 0;
}
