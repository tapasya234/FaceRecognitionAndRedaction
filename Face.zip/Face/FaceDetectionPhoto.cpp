/*
* Face detection tutorial using Casscade Classifier and Haar
* http://docs.opencv.org/3.0-beta/doc/tutorials/objdetect/cascade_classifier/cascade_classifier.html
*/

#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <sstream>
#include <string>

using namespace std;
using namespace cv;

/** Function Headers */

cv::Mat detectAndDisplay(cv::Mat frame);
void read_csv(const string& filename, vector<Mat>& images, vector<int>& labels, char seperator = ';');

/** Global variables*/
String path = "E:/OpenCV-2.4.13/opencv/sources/data/haarcascades/";
String face_cascade_name = path + "haarcascade_frontalface_alt.xml";
//String eyes_cascade_name = path + "haarcascade_eye_tree_eyeglasses.xml";

CascadeClassifier face_cascade;
//CascadeClassifier eyes_cascade;

//String window_name = "Capture - Face Detection";

/** @function main*/
int main() {
	//cv::VideoCapture capture;
	const int noPhotos = 25;
	string photosPath[noPhotos] = {"Dataset\\1.jpg", 
						   "Data\\2.jpg",
						   "Data\\3.jpg",
						   "Data\\4.jpg",
						   "Data\\file.jpeg", 
						   "Data\\file1.jpeg", 
						   "Data\\file2.jpeg", 
						   "Data\\file3.jpeg", 
						   "Data\\IMG_0077.jpg", 
						   "Data\\IMG_0131.jpg", 
						   "Data\\IMG_0132.jpg", 
						   "Data\\IMG_0250.jpg",
						   "Data\\IMG_0395.jpg", 
						   "Data\\IMG_0398.png", 
						   "Data\\IMG_0495.jpg", 
						   "Data\\IMG_0505.jpg",
						   "Data\\IMG_0724.jpg",
						   "Data\\IMG_0722.jpg",
						   "Data\\IMG_0721.jpg",
						   "Data\\IMG_0810.jpg", 
						   "Data\\IMG_0918.jpg", 
						   "Data\\IMG_0890.jpg", 
						   "Data\\IMG_2429.jpg", 
						   "Data\\IMG_2430.jpg",
						   "Data\\IMG_5599.jpg" };


	//cv::Mat photo = cv::imread(photosPath[0]);

	// -- 1. Load the cascades
	if (!face_cascade.load(face_cascade_name)) {
		cout << "--(!)Error loading face cascade" << endl;
		return -1;
	}


	//Read the csv file
	//for (int i = 0; i < noPhotos; i++){
	/*int i = 21;
	std::stringstream ss;
	ss << "file" << i << ".jpg";
	string window_name = ss.str(); */
	string window_name = "Dataset\\file30.jpg";
		cv::Mat photo = cv::imread("photo9.jpg");
		if (photo.empty()) {
			cout << "--(!)No captured frame -- Break!" << endl;
			exit(1);
		}

		// -- 3.Apply the classifier to the frame
		cv::Mat resizedFace = detectAndDisplay(photo);
		//imshow("Photo", testSample); */

		
		//strcat(window_name, i);

		//window_name = window_name + ".jpg";
		imshow(window_name, resizedFace);
		imwrite(window_name, resizedFace);
		
	//}
	
	cv::waitKey(0);
	return 0;
}

/* @function detectAndDisplay */
cv::Mat detectAndDisplay(cv::Mat frame) {
	std::vector<Rect> faces;
	Mat frame_gray;

	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);
	equalizeHist(frame_gray, frame_gray);

	// -- Detect faces
	face_cascade.detectMultiScale(frame_gray, faces);
		//, 1.1, 2, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));

	cv::Mat resizedFace;
	if (!faces.empty()) {
		for (size_t i = 0; i < faces.size(); i++) {
			
			cv::Rect face_i = faces[i];
			cv::Mat face = frame_gray(faces[i]);
			cv::resize(face, resizedFace, Size(92, 112), 1.0, 1.0, INTER_CUBIC);
			
		}
	}

	return resizedFace;
}

static void read_csv(const string& filename, vector<Mat>& images, vector<int>& labels, char seperator) {
	std::ifstream file(filename.c_str(), ifstream::in);

	seperator = ';';
	if (!file) {
		string error_message = "No valide input file is given, please check the given filename";
		CV_Error(CV_StsBadArg, error_message);
	}

	string line, path, classlabel;
	while (getline(file, line)) {
		stringstream liness(line);
		getline(liness, path, seperator);
		getline(liness, classlabel);

		//imshow("Photo", path);
		cout << classlabel.c_str() << endl;
		if (!path.empty() && !classlabel.empty()) {
			images.push_back(imread(path, 0));
			labels.push_back(atoi(classlabel.c_str()));
		}
	}
}